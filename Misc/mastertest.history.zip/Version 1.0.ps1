function Show-Menu{
     param (
           [string]$Title = 'Welcome to the new hire experience!'
     )
     Clear-Host
     Write-Host "================ $Title ================"
     
     Write-Host "1: Press '1' to create a new non-onboarded user."
     Write-Host "2: Press '2' to request access for a user."
     Write-Host "3: Press '3' to give access to a non-onboarded user."
     Write-Host "4: Press '4' to clear all variables."
     Write-Host "Q: Press 'Q' to quit."
}

function createuser{
if ($firstname -eq $null){$firstname = Read-Host 'First Name'}
if ($lastname -eq $null){$lastname = Read-Host 'Last Name'}
$fndig = 1
$newuser = $firstname.substring(0,$fndig) + $lastname

while (dsquery.exe user -samid $newuser) {$newuser = $firstname.substring(0,$fndig++) + $lastname
    if ($fndig -ge $firstname.length) {break
    write-host 'Userid could not be generated based on first name'
        <# This will automatically assign the user id as first initial last name. If the 
        user id is already in use it will add in the letters of the first name until 
        it is spelled out #>
    do {
        $proceed = 'no'
        $newuser = Read-Host 'Enter Userid'
        #validation code
        if (dsquery.exe user -samid $newuser) {
        Write-Host "$newuser is already in use."
        }
        else {$proceed = 'yes'
        'The username is available'
        pause}
        } until ($proceed -eq 'yes')            
        }
        }
"Please confirm the entered information is correct:

Name: $firstname $lastname
UserID: $newuser

The information will be entered EXACLY as shown."
pause

new-aduser  `
    -samaccountname $newuser `
    -AccountPassword (ConvertTo-SecureString -AsPlainText 'Temp001' -Force) `
    -name "$firstname $lastname" `
    -givenname "$firstname" `
    -surname "$lastname" `
    -DisplayName "$firstname $lastname" `
    -UserPrincipalName "$newuser@sbasite.com"`
    -Enabled $true `
    -ChangePasswordAtLogon $true `
    -EmailAddress "$newuser@sbasite.com"`
    -Company 'SBA Network Services Inc.'`
    -Path 'OU=HR Onboarding,OU=IT Operations,DC=sbasite,DC=com'
Set-ADUser $newuser -Add @{ProxyAddresses="SMTP:$newuser@sbasite.com","smtp:$newuser@sbacommunication.mail.onmicrosoft.com"} 
Set-ADUser $newuser -Add @{targetAddress="SMTP:$newuser@sbacommunication.mail.onmicrosoft.com"}
Start-Process -FilePath "\\fl1fs1.sbasite.com\it$\Helpdesk\DirSync\DirSync.exe"

'The process has completed. The user is ready.'
"The userid assigned is $newuser"
pause
    }

function requestcopy{
if ($OldUser -eq $null){$OldUser = Read-Host 'Userid of the user you are copying groups from'}
if ($NewUser -eq $null){$NewUser = Read-Host 'Userid of the user you are copying to'}
    # These variables accept the user input.

$NewUserName = (Get-ADUser $NewUser -Properties DisplayName | Select Displayname |
  Format-Table -HideTableHeaders | Out-String).Trim()
$NewUserTitle = (Get-ADUser $NewUser -Properties Title | Select Title |
  Format-Table -HideTableHeaders | Out-String).Trim()
$NewUserDepartment = (Get-ADUser $NewUser -Properties Department | Select Department |
  Format-Table -HideTableHeaders | Out-String).Trim()
$NewUserManager = (Get-ADUser $NewUser -Properties Manager |
  Select @{n='Manager';e={$_.Manager -replace '^CN=(.+?),(?:CN|OU).+','$1'}} |
  Format-Table -HideTableHeaders | Out-String).Trim()
    #These are the variables for the new hire.

if (dsquery.exe user -samid $OldUser){"$OldUser validated in Active Directory."}
  else {"$OldUser is not a recognized UserID."
  Pause
  Exit}
Write-Host
Write-Host
Write-Output  "This will copy security groups from $OldUser to $NewUser."
Pause
    # This validates the userids in AD and lets you know if you entered in something that doesn't exist.
    

if ( (Get-Date -UFormat %p) -eq "AM" ) { 
  $Greeting = "Good morning," 
  } #End if
else {
  $Greeting = "Good afternoon,"
  } #end else
    # This checks time of day and sets the greeting

New-Item -ItemType directory -Force -Path I:\"New Hire Logs"\"$NewUser"\ -ea SilentlyContinue
    # So we can dump a logfile at the end of the script

Clear-Host
    # To tidy up the screen from any dialogue of creating the directory

Write-host The script is running. This is going to take a few minutes...
    # We want to make sure the user knows the script is doing its job.

$Groups = Get-ADPrincipalGroupMembership $OldUser |
  Get-ADGroup -Properties Name,managedby | 
  Select Name, @{n='ManagedBy';e={$_.ManagedBy -replace '^CN=(.+?),(?:CN|OU).+','$1'}} |
  Where-Object {$_.managedby -ne ""} | 
  group-object -property managedby
$GroupList = Get-ADPrincipalGroupMembership $OldUser |
  Get-ADGroup -Properties Name,managedby | 
  Select Name, @{n='ManagedBy';e={$_.ManagedBy -replace '^CN=(.+?),(?:CN|OU).+','$1'}} |
  Where-Object {$_.managedby -ne ""}
    # These pull the groups that need approval and groups them by managedby. 
  $OFS = "`t`n"  
  
foreach ($Group in $Groups)
  {
$ManagerMail = get-aduser -filter "displayname -like '$($Group.name)'" -properties Mail | Select Mail |
  Format-Table -HideTableHeaders | Out-String
$ManagerName = (get-aduser -filter "displayname -like '$($Group.name)'" -properties GivenName | 
  Select GivenName | Format-Table -HideTableHeaders | Out-String).Trim()
$Groupnames = ($group.group.name | Out-String).Trim()
    # These set the varialbe for each manager and the groups they own
if ($Groupnames -like  "*Application-Hyperion-Planning*"){
$Managermail = "SManas@sbasite.com"
$Managername = "Sergio"
 }
 if ($Groupnames -like  "*RSMPO*"){
$Managermail = "lcestare@sbasite.com"
 }

 [string]$emailbody = ""
$Outlook = New-Object -ComObject Outlook.Application
  $Mail = $Outlook.Application.CreateItemFromTemplate("H:\Helpdesk\Scripts\Template.oft")
  $Mail.To = $ManagerMail
  $Mail.Subject = "Security Group Access Request - $newusername"
  [string]$Mail.Body =  "$Greeting  $ManagerName


Please approve/deny $NewUserName for access to the following group(s): 
 
$groupnames

Their title is $NewUserTitle and they work in $NewUserDepartment for $NewUserManager"
  $Mail.Display()
  }
    # This is the email that goes to each approver. It uses the variables to fill in relavent information.

$Grouplist | Out-File I:\"New Hire Logs"\"$NewUser"\""$Olduser" Groups.log"
    #This dumps the logfile to your I Drive

Clear-Host 
Write-Host 'The script has completed. The following groups need authorization:' 
    Write-Host
$GroupList
    Write-Host 
    Write-Host  
Pause
}

function copyaccess{
if ($source -eq $null){$source = read-host 'Userid of the user you are transferring from'}
if ($newuser -eq $null){read-host 'Userid of the user you are transferring to'}

    $CopyFromUser = Get-ADUser $source -prop MemberOf
    $CopyToUser = Get-ADUser $newuser -prop MemberOf
    $targetou = Get-ADUser -Identity $source -Properties distinguishedname,cn |
        Select-Object @{n='ParentContainer';e={$_.distinguishedname -replace '^.+?,(CN|OU.+)','$1'}} | 
        Format-Table -HideTableHeaders | out-string

$CopyFromUser.MemberOf | Where-Object{$CopyToUser.MemberOf -notcontains $_} |  Add-ADGroupMember -Member $CopyToUser
Get-ADUser $newuser | Move-ADObject -TargetPath "$targetou"
}