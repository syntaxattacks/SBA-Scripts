function Show-Menu
{
     param (
           [string]$Title = 'Welcome to the new hire experience!'
     )
     cls
     Write-Host "================ $Title ================"
     
     Write-Host "1: Press '1' to create a new user."
     Write-Host "2: Press '2' to request access for a user."
     Write-Host "3: Press '3' to give access to a user."
     Write-Host "4: Press '4' to clear all variables."
     Write-Host "Q: Press 'Q' to quit."
}




function createuser{
if ($firstname -eq $null){$firstname = Read-Host 'First Name'}
if ($lastname -eq $null){$lastname = Read-Host 'Last Name'}
$fndig = 1
if {$newuser -eq $null){$newuser = $firstname.substring(0,$fndig) + $lastname
}
do {
        $proceed = "no"
        $newuser = Read-Host "userid of manager"
        #validation code
        if (dsquery user -samid $newuser) {
        $proceed = "yes"
        }
        else {"The username is not valid"}
        } until ($proceed -eq "yes") 


while (dsquery user -samid $newuser) {$newuser = $firstname.substring(0,$fndig++) + $lastname
    if ($fndig > $firstname.length) {break}
    write-host "Userid could not be generated based on first name"
        <# This will automatically assign the user id as first initial last name. If the 
        user id is already in use it will add in the letters of the first name until 
        it is spelled out#> 
    do {
        $proceed = "no"
        $newuser = Read-Host "Enter Userid"
        #validation code
        if (dsquery user -samid $newuser) {
        Write-Host "$newuser is already in use."
        }
        else {$proceed = "yes"
        "The username is available"}
        } until ($proceed -eq "yes")            
        }
"Please confirm the entered information is correct:

Name: $firstname $lastname

The information will be entered EXACLY as shown."
pause

new-aduser  `
    -samaccountname $newuser `
    -AccountPassword (ConvertTo-SecureString -AsPlainText "Temp001" -Force) `
    -name "$firstname $lastname" `
    -givenname "$firstname" `
    -surname "$lastname" `
    -DisplayName "$firstname $lastname" `
    -UserPrincipalName "$newuser@sbasite.com"`
    -Enabled $true `
    -ChangePasswordAtLogon $true `
    -EmailAddress "$newuser@sbasite.com"`
    -Company "SBA Network Services Inc."`
    -Path 'OU=HR Onboarding,OU=IT Operations,DC=sbasite,DC=com'
Set-ADUser $newuser -Add @{ProxyAddresses="SMTP:$newuser@sbasite.com","smtp:$newuser@sbacommunication.mail.onmicrosoft.com"} 
Set-ADUser $newuser -Add @{targetAddress="SMTP:$newuser@sbacommunication.mail.onmicrosoft.com"}
Start-Process -FilePath "\\fl1fs1.sbasite.com\it$\Helpdesk\DirSync\DirSync.exe"

"The process has completed. The user is ready."
"The userid assigned is $newuser"
pause
    }


function copyaccess{
if ($source -eq $null){$source = read-host "Userid of the user you are transferring from"}
if {$newuser -eq $null){read-host "Userid of the user you are transferring to"}

    $CopyFromUser = Get-ADUser $source -prop MemberOf
    $CopyToUser = Get-ADUser $newuser -prop MemberOf
    $targetou = Get-ADUser -Identity $source -Properties distinguishedname,cn |
        select @{n='ParentContainer';e={$_.distinguishedname -replace '^.+?,(CN|OU.+)','$1'}} | 
        ft -HideTableHeaders | out-string

$CopyFromUser.MemberOf | Where{$CopyToUser.MemberOf -notcontains $_} |  Add-ADGroupMember -Member $CopyToUser
Get-ADUser $newuser | Move-ADObject -TargetPath "$targetou"
}